<?php

namespace Yoast\WP\SEO\Exceptions\Addon_Installation;

use Exception;

/**
 * Class Addon_Activation_Error_Exception
 */
class Addon_Activation_Error_Exception extends Exception {}
